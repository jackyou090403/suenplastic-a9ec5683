# 厦门塑恩 SUEN Plastic — 静态站点发布包

## 内容
- `index.html` 首页 + 各路由对应 `xxx/index.html` 文件
- `assets/` 构建产物（JS / CSS / 字体 / 图片，文件名带 hash，可长缓存）
- `sitemap.xml` 站点地图（符合 sitemaps.org 0.9 标准，含 hreflang，可提交 360/百度/Google 站长）
- `robots.txt`
- `baidu_verify_codeva-PmnCpnkRCV.html` 百度站长验证
- `nginx.conf.example` Nginx SPA 伪静态参考配置

## 部署
1. 解压后，将整个目录上传至服务器 web 根目录（例如 `/var/www/suenplastic`）。
2. 参考 `nginx.conf.example` 配置站点；核心伪静态：
   ```
   location / { try_files $uri $uri/index.html $uri/ /index.html; }
   ```
   即可保证刷新任意路由不会 404。
3. 重载 Nginx：`nginx -t && nginx -s reload`。

## 说明
- 本包为纯静态 SPA 产物，无需 Node 运行环境。
- 管理后台 `/admin` 与登录 `/auth` 依赖 Lovable Cloud 后端 API，需保证浏览器能访问对应后端域名（已内置在 JS 中）。
- 资源文件名包含 hash，可放心配置长缓存（assets 目录已建议 1 年）。

import{N as t,O as o}from"./index-DCZ-844U.js";const n=()=>t.jsx(o,{});export{n as component};

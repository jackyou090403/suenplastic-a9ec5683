import{a as o}from"./index-DCZ-844U.js";const t=o;export{t as component};

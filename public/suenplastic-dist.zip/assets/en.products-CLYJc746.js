import{k as o}from"./index-DCZ-844U.js";const n=o;export{n as component};

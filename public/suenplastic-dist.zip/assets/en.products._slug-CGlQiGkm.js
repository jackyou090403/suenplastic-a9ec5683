import{j as o}from"./index-DCZ-844U.js";const e=o;export{e as component};
